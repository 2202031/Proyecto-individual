// screens/UserListScreen.js
import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { Button, List, IconButton } from 'react-native-paper';

const UserListScreen = ({ navigation, route }) => {
  const [users, setUsers] = useState([]);

  const addUser = () => {
    if (route.params) {
      setUsers([...users, { name: route.params.name, email: route.params.email }]);
      route.params = null;
    }
  };

  const handleDelete = (index) => {
    const newUsers = [...users];
    newUsers.splice(index, 1);
    setUsers(newUsers);
  };

  const handleEdit = (index) => {
    navigation.navigate('EditUser', { user: users[index], index });
  };

  const handleShowDetails = (user) => {
    navigation.navigate('UserDetails', { user });
  };

  addUser();

  return (
    <View style={styles.container}>
      <Button mode="contained" onPress={() => navigation.navigate('Register')}>
        Add User
      </Button>
      {users.map((user, index) => (
        <List.Item
          key={index}
          title={user.name}
          description={user.email}
          right={props => (
            <View style={styles.icons}>
              <IconButton icon="pencil" onPress={() => handleEdit(index)} />
              <IconButton icon="delete" onPress={() => handleDelete(index)} />
              <IconButton icon="information" onPress={() => handleShowDetails(user)} />
            </View>
          )}
        />
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  icons: {
    flexDirection: 'row',
  },
});

export default UserListScreen;
