import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const User = () => {
  return (
    <View>
      <Text>Hola desde user uwu</Text>
    </View>
  )
}

export default User

const styles = StyleSheet.create({})