import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const UserDetalles = () => {
  return (
    <View>
      <Text>Datos detallados</Text>
      <Text>Nombre: Brian</Text>
      <Text>Apellido: Osorio</Text>
    </View>
  )
}

export default UserDetalles

const styles = StyleSheet.create({})