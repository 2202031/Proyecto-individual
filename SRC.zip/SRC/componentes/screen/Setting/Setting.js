import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Setting = () => {
  return (
    <View>
      <Text>Hola desde setting uwu</Text>
    </View>
  )
}

export default Setting

const styles = StyleSheet.create({})