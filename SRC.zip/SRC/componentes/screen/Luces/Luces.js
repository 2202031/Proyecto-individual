import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Luces = () => {
  return (
    <View>
      <Text>Hola desde luces uwu</Text>
    </View>
  )
}

export default Luces

const styles = StyleSheet.create({})