import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const Puertas = () => {
  return (
    <View>
      <Text>Hola desde puertas uwu</Text>
    </View>
  )
}

export default Puertas

const styles = StyleSheet.create({})